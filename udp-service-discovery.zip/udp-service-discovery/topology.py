#!/usr/bin/env python3
"""Mininet topology for the UDP service discovery assignment."""
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info


class ServiceDiscoveryTopo(Topo):
    def build(self):
        switch = self.addSwitch("s1", protocols="OpenFlow13")
        hosts = [
            ("registry", "10.0.0.1/24"),
            ("server1", "10.0.0.2/24"),
            ("server2", "10.0.0.3/24"),
            ("client1", "10.0.0.4/24"),
            ("client2", "10.0.0.5/24"),
        ]
        for name, ip in hosts:
            host = self.addHost(name, ip=ip)
            self.addLink(host, switch)


def main():
    setLogLevel("info")
    topo = ServiceDiscoveryTopo()
    net = Mininet(topo=topo, controller=None, switch=OVSSwitch, autoSetMacs=True,
                  build=True, waitConnected=False)
    net.addController("c0", controller=RemoteController, ip="127.0.0.1", port=6653)
    try:
        net.start()
        info("\n*** Topology ready: registry=10.0.0.1, servers=10.0.0.2/10.0.0.3, clients=10.0.0.4/10.0.0.5\n")
        info("*** Start registry and services from the Mininet CLI; type exit to stop.\n")
        CLI(net)
    finally:
        net.stop()


if __name__ == "__main__":
    main()
