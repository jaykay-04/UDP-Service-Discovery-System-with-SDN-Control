#!/usr/bin/env python3
"""Example UDP service that advertises itself and responds to client requests."""
import argparse
import signal
import socket
import threading
import time

from protocol import (DEFAULT_REGISTRY_PORT, DEFAULT_SERVICE_PORT, DEFAULT_TTL,
                      decode, encode, guess_local_ip)


class ServiceServer:
    def __init__(self, name, registry_ip, registry_port, listen_ip, port, ttl, metadata):
        self.name = name
        self.registry = (registry_ip, registry_port)
        self.listen_ip = listen_ip
        self.port = port
        self.ttl = ttl
        self.metadata = metadata
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((listen_ip, port))
        self.sock.settimeout(0.5)
        self.advertised_ip = guess_local_ip(registry_ip)
        self.advertise_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def advertise(self):
        msg = {"type": "REGISTER", "service": self.name, "ip": self.advertised_ip,
               "port": self.port, "ttl": self.ttl, "metadata": self.metadata}
        try:
            self.advertise_sock.sendto(encode(msg), self.registry)
            self.advertise_sock.settimeout(1.0)
            response, _ = self.advertise_sock.recvfrom(8192)
            decoded = decode(response)
            if decoded.get("type") == "ERROR":
                print(f"[server:{self.name}] registry error: {decoded.get('error')}", flush=True)
            else:
                print(f"[server:{self.name}] advertisement acknowledged: {decoded}", flush=True)
        except (OSError, ValueError) as exc:
            print(f"[server:{self.name}] advertisement failed: {exc}", flush=True)

    def heartbeat_loop(self):
        # Refresh well before TTL expiry; UDP does not guarantee delivery.
        while self.running:
            self.advertise()
            for _ in range(max(1, self.ttl // 3)):
                if not self.running:
                    return
                time.sleep(1)

    def handle(self, msg, peer):
        kind = msg.get("type")
        if kind == "PING":
            response = {"type": "PONG", "service": self.name, "time": time.time()}
        elif kind == "REQUEST":
            request_id = msg.get("request_id", "unknown")
            text = str(msg.get("payload", "hello"))
            response = {"type": "RESPONSE", "service": self.name,
                        "request_id": request_id,
                        "result": f"{self.name} received: {text}", "time": time.time()}
        else:
            response = {"type": "ERROR", "error": f"unsupported request type: {kind}"}
        self.sock.sendto(encode(response), peer)
        print(f"[server:{self.name}] {kind} from {peer[0]}:{peer[1]}", flush=True)

    def run(self):
        print(f"[server:{self.name}] listening on {self.listen_ip}:{self.port}; advertised IP {self.advertised_ip}", flush=True)
        heartbeat = threading.Thread(target=self.heartbeat_loop, daemon=True)
        heartbeat.start()
        while self.running:
            try:
                payload, peer = self.sock.recvfrom(65507)
                try:
                    msg = decode(payload)
                    self.handle(msg, peer)
                except (ValueError, TypeError) as exc:
                    self.sock.sendto(encode({"type": "ERROR", "error": str(exc)}), peer)
            except socket.timeout:
                continue
            except OSError as exc:
                if self.running:
                    print(f"[server:{self.name}] socket error: {exc}", flush=True)
        try:
            self.advertise_sock.sendto(encode({"type": "UNREGISTER", "service": self.name,
                                               "ip": self.advertised_ip, "port": self.port}), self.registry)
        except OSError:
            pass
        self.sock.close()
        self.advertise_sock.close()
        print(f"[server:{self.name}] stopped", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", required=True, help="service name clients discover")
    parser.add_argument("--registry-ip", required=True)
    parser.add_argument("--registry-port", type=int, default=DEFAULT_REGISTRY_PORT)
    parser.add_argument("--listen-ip", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=DEFAULT_SERVICE_PORT)
    parser.add_argument("--ttl", type=int, default=DEFAULT_TTL)
    parser.add_argument("--metadata", default="{}", help="JSON metadata, e.g. '{\"zone\":\"north\"}'")
    args = parser.parse_args()
    import json
    try:
        metadata = json.loads(args.metadata)
    except json.JSONDecodeError as exc:
        parser.error(f"--metadata must be valid JSON: {exc}")
    if not isinstance(metadata, dict):
        parser.error("--metadata must be a JSON object")
    app = ServiceServer(args.name, args.registry_ip, args.registry_port,
                        args.listen_ip, args.port, args.ttl, metadata)
    def stop(_sig, _frame):
        app.running = False
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    app.run()


if __name__ == "__main__":
    main()
