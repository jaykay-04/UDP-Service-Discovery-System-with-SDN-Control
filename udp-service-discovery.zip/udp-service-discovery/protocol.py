"""Shared protocol helpers for the UDP service discovery project."""
import json
import socket
import time

PROTOCOL_VERSION = 1
DEFAULT_REGISTRY_PORT = 9999
DEFAULT_SERVICE_PORT = 10000
DEFAULT_TTL = 6


def encode(message: dict) -> bytes:
    """Encode one application message as UTF-8 JSON for a UDP datagram."""
    message = {"version": PROTOCOL_VERSION, **message}
    return json.dumps(message, separators=(",", ":")).encode("utf-8")


def decode(payload: bytes) -> dict:
    """Decode and minimally validate a received application message."""
    message = json.loads(payload.decode("utf-8"))
    if not isinstance(message, dict):
        raise ValueError("message must be a JSON object")
    if message.get("version") != PROTOCOL_VERSION:
        raise ValueError("unsupported protocol version")
    return message


def guess_local_ip(destination: str) -> str:
    """Return the local IPv4 address selected for reaching destination."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect((destination, 9))
        return sock.getsockname()[0]
    finally:
        sock.close()


def now() -> float:
    return time.time()
