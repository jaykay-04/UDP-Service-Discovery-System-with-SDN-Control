#!/usr/bin/env python3
"""UDP discovery client; can list services or invoke a discovered service."""
import argparse
import json
import socket
import uuid

from protocol import DEFAULT_REGISTRY_PORT, decode, encode


def request(sock, endpoint, message, timeout):
    sock.settimeout(timeout)
    sock.sendto(encode(message), endpoint)
    payload, peer = sock.recvfrom(65507)
    return decode(payload), peer


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry-ip", required=True)
    parser.add_argument("--registry-port", type=int, default=DEFAULT_REGISTRY_PORT)
    parser.add_argument("--service", default="", help="service name; omit to list all services")
    parser.add_argument("--invoke", action="store_true", help="send a request to the first discovered instance")
    parser.add_argument("--payload", default="hello over UDP")
    parser.add_argument("--timeout", type=float, default=2.0)
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        try:
            result, _ = request(sock, (args.registry_ip, args.registry_port),
                                {"type": "DISCOVER", "service": args.service}, args.timeout)
        except (socket.timeout, OSError, ValueError) as exc:
            raise SystemExit(f"Discovery failed: {exc}")

        if result.get("type") != "DISCOVERY_RESULT":
            raise SystemExit(f"Unexpected registry response: {result}")
        services = result.get("services", [])
        print(json.dumps(result, indent=2))
        if not services:
            print("No matching active services found.")
            return
        if args.invoke:
            service = services[0]
            request_id = str(uuid.uuid4())
            try:
                response, peer = request(sock, (service["ip"], int(service["port"])),
                                         {"type": "REQUEST", "request_id": request_id,
                                          "payload": args.payload}, args.timeout)
                print(f"\nInvocation response from {peer[0]}:{peer[1]}:")
                print(json.dumps(response, indent=2))
            except (socket.timeout, OSError, ValueError) as exc:
                print(f"Service invocation failed: {exc}")
                raise SystemExit(2)


if __name__ == "__main__":
    main()
