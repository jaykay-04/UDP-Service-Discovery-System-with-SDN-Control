#!/usr/bin/env python3
"""UDP service registry: receives advertisements and answers discovery queries."""
import argparse
import json
import os
import signal
import socket
import time
from collections import OrderedDict

from protocol import DEFAULT_REGISTRY_PORT, decode, encode

EVENT_FILE = os.environ.get("SDN_EVENTS_FILE", "/tmp/udp_sdn_events.jsonl")
MAX_DATAGRAM = 65507


class Registry:
    def __init__(self, host: str, port: int, default_ttl: int):
        self.host, self.port, self.default_ttl = host, port, default_ttl
        # service name -> instance key -> record
        self.services = {}
        self.running = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((host, port))
        self.sock.settimeout(0.5)

    def event(self, action: str, ip: str, service: str, reason: str = ""):
        """Append a control-plane event for the Ryu app to consume."""
        event = {"action": action, "ip": ip, "service": service,
                 "reason": reason, "time": time.time()}
        try:
            with open(EVENT_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except OSError as exc:
            print(f"[registry] WARNING: cannot write SDN event file {EVENT_FILE}: {exc}", flush=True)
        print(f"[registry] SDN event: {event}", flush=True)

    def _host_has_live_instance(self, ip: str) -> bool:
        return any(rec["ip"] == ip for instances in self.services.values() for rec in instances.values())

    def register(self, msg: dict, peer: tuple):
        service = str(msg.get("service", "")).strip()
        ip = str(msg.get("ip") or peer[0]).strip()
        try:
            port = int(msg.get("port"))
            ttl = max(3, min(int(msg.get("ttl", self.default_ttl)), 120))
        except (TypeError, ValueError):
            raise ValueError("REGISTER requires integer port and ttl")
        if not service or len(service) > 80 or not (1 <= port <= 65535):
            raise ValueError("invalid service name or port")
        # Restrict advertised address to IPv4 literal; the client needs a reachable endpoint.
        socket.inet_aton(ip)
        key = f"{ip}:{port}"
        instances = self.services.setdefault(service, {})
        was_new = key not in instances
        instances[key] = {"service": service, "ip": ip, "port": port,
                          "ttl": ttl, "expires_at": time.time() + ttl,
                          "metadata": msg.get("metadata", {})}
        if was_new:
            self.event("UNBLOCK_HOST", ip, service, "service registered")
        print(f"[registry] {'registered' if was_new else 'refreshed'} {service} at {ip}:{port} ttl={ttl}s", flush=True)
        return {"type": "REGISTERED", "service": service, "expires_in": ttl}

    def discover(self, msg: dict):
        name = str(msg.get("service", "")).strip()
        now = time.time()
        found = []
        for service, instances in self.services.items():
            if name and service != name:
                continue
            for rec in instances.values():
                if rec["expires_at"] > now:
                    found.append({"service": rec["service"], "ip": rec["ip"],
                                  "port": rec["port"],
                                  "ttl_remaining": max(0, int(rec["expires_at"] - now)),
                                  "metadata": rec["metadata"]})
        return {"type": "DISCOVERY_RESULT", "service": name or "*", "services": found}

    def expire(self):
        now = time.time()
        expired = []
        for service, instances in list(self.services.items()):
            for key, rec in list(instances.items()):
                if rec["expires_at"] <= now:
                    expired.append((service, key, rec))
                    del instances[key]
            if not instances:
                del self.services[service]
        for service, key, rec in expired:
            print(f"[registry] EXPIRED {service} at {key}", flush=True)
            if not self._host_has_live_instance(rec["ip"]):
                self.event("BLOCK_HOST", rec["ip"], service, "advertisement timed out")

    def handle(self, payload: bytes, peer: tuple):
        try:
            msg = decode(payload)
            kind = msg.get("type")
            if kind == "REGISTER":
                response = self.register(msg, peer)
            elif kind == "DISCOVER":
                response = self.discover(msg)
            elif kind == "UNREGISTER":
                service = str(msg.get("service", "")).strip()
                ip = str(msg.get("ip") or peer[0]).strip()
                port = int(msg.get("port"))
                instances = self.services.get(service, {})
                instances.pop(f"{ip}:{port}", None)
                if not instances:
                    self.services.pop(service, None)
                if not self._host_has_live_instance(ip):
                    self.event("BLOCK_HOST", ip, service, "service unregistered")
                response = {"type": "UNREGISTERED", "service": service}
            elif kind == "PING":
                response = {"type": "PONG", "time": time.time()}
            else:
                response = {"type": "ERROR", "error": f"unknown message type: {kind}"}
            self.sock.sendto(encode(response), peer)
        except (ValueError, TypeError, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
            try:
                self.sock.sendto(encode({"type": "ERROR", "error": str(exc)}), peer)
            except OSError:
                pass
        except OSError as exc:
            print(f"[registry] socket error: {exc}", flush=True)

    def run(self):
        print(f"[registry] listening on UDP {self.host}:{self.port}; SDN event file: {EVENT_FILE}", flush=True)
        while self.running:
            try:
                payload, peer = self.sock.recvfrom(MAX_DATAGRAM)
                self.handle(payload, peer)
            except socket.timeout:
                pass
            except OSError as exc:
                if self.running:
                    print(f"[registry] socket error: {exc}", flush=True)
            self.expire()
        self.sock.close()
        print("[registry] stopped", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="0.0.0.0", help="bind address (default: all IPv4 interfaces)")
    parser.add_argument("--port", type=int, default=DEFAULT_REGISTRY_PORT)
    parser.add_argument("--ttl", type=int, default=6, help="default advertisement TTL in seconds")
    args = parser.parse_args()
    app = Registry(args.host, args.port, args.ttl)
    def stop(_sig, _frame):
        app.running = False
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    app.run()


if __name__ == "__main__":
    main()
