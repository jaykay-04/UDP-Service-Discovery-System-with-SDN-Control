# UDP-Based Service Discovery System with SDN (Mininet + Ryu)

## 1. What this project does

This project implements the **Service Discovery System** from the assignment screenshot. Service providers announce their availability over **UDP**. A registry maintains a short-lived list of services, and clients query that registry to discover a matching service. Advertisements must be refreshed before their TTL expires; otherwise the registry removes the instance and asks the SDN controller to block traffic to the unavailable host.

**All application communication is UDP.** The only TCP connection in the lab is the OpenFlow control connection between Open vSwitch and the Ryu SDN controller; that is part of SDN infrastructure, not the service-discovery application protocol.

### Main features

- UDP service advertisements and periodic refresh/heartbeat.
- Central service registry with TTL-based expiry.
- UDP client discovery by service name, or listing all services.
- Example UDP service invocation (`REQUEST` / `RESPONSE`) after discovery.
- Graceful unregister when a service exits normally.
- Unavailable-server detection when advertisements stop arriving.
- Dynamic SDN integration: registry writes `UNBLOCK_HOST` / `BLOCK_HOST` events; Ryu turns these into OpenFlow rules that remove or add a drop rule for the host's IPv4 destination.
- Two service hosts and two client hosts in a reproducible Mininet topology.
- Small protocol unit tests and a repeatable test plan.

## 2. Architecture

```text
 server1 (10.0.0.2:10000) ----\
                               \
 server2 (10.0.0.3:10000) ------ s1 (OpenFlow 1.3) ------ registry (10.0.0.1:9999/UDP)
                               /                              ^
 client1 (10.0.0.4) ----------/                               | UDP DISCOVER / results
 client2 (10.0.0.5) -----------------------------------------+

 registry -- append JSON control event to shared event file --> Ryu SDN controller
 Ryu controller -- OpenFlow flow modification --> s1
```

The diagram is logical; every Mininet host is connected to switch `s1`.

### Components and what each one does

| File / component | Responsibility |
|---|---|
| `protocol.py` | Shared UDP message encoding/decoding. Messages are JSON encoded as UTF-8 and include protocol version `1`. |
| `registry.py` | UDP registry listening on port `9999`; stores registrations, answers `DISCOVER`, expires stale records, and logs SDN events. |
| `service_server.py` | Example service provider. Advertises itself, refreshes its TTL, listens for client requests on UDP port `10000` by default, and unregisters on graceful shutdown. |
| `client.py` | Queries the registry and optionally invokes the first matching discovered service. |
| `benchmark.py` | Measures discovery latency and success rate over repeated UDP queries. |
| `ryu_controller.py` | Ryu OpenFlow 1.3 learning-switch app. Learns MAC addresses and dynamically installs/removes IPv4 destination drop rules from registry events. |
| `topology.py` | Defines the Mininet topology and starts a remote OpenFlow controller at `127.0.0.1:6653`. |
| `tests/test_protocol.py` | Tests protocol JSON round-tripping and rejection of invalid messages. |
| `scripts/reset_sdn_events.sh` | Clears the local event log before a fresh run. |

## 3. UDP application protocol

Each application message is one UDP datagram containing a JSON object. The `version` field is currently `1`.

| Message | Direction | Purpose |
|---|---|---|
| `REGISTER` | Service server → registry | Advertises service name, IP, port, TTL, and optional metadata. |
| `REGISTERED` | Registry → service server | Acknowledges a registration/refresh. |
| `DISCOVER` | Client → registry | Looks up a specific service, or all services when `service` is empty. |
| `DISCOVERY_RESULT` | Registry → client | Returns active service endpoints and remaining TTL. |
| `REQUEST` | Client → service server | Example application request with a request ID and payload. |
| `RESPONSE` | Service server → client | Example response to a request. |
| `UNREGISTER` | Service server → registry | Removes an instance when it shuts down normally. |
| `PING` / `PONG` | Any supported endpoint | Simple connectivity check. |
| `ERROR` | Receiver → sender | Reports malformed or unsupported application messages. |

UDP is connectionless and does not guarantee delivery, ordering, or retransmission. This implementation uses periodic advertisements and client-side timeouts, but it is a teaching/demo implementation rather than a production-grade registry. The registry replies to registrations, which gives the service process a basic acknowledgement; it does not implement a full retry/backoff protocol.

## 4. SDN integration design

The registry appends newline-delimited JSON events to `/tmp/udp_sdn_events.jsonl` (override with `SDN_EVENTS_FILE`). Ryu watches that shared file and applies events to connected OpenFlow switches:

- `UNBLOCK_HOST`: delete the priority-100 drop rule for that IPv4 destination when a service becomes active.
- `BLOCK_HOST`: install a priority-100 rule with no forwarding actions, dropping IPv4 packets whose destination is the unavailable host.
- Priority-0 table-miss behavior sends unknown packets to the controller, which learns MAC addresses and forwards packets. Priority-1 learned forwarding rules are lower priority than the priority-100 block rule.

**Why a shared file?** Mininet hosts run in separate network namespaces and cannot generally send to the controller process's `127.0.0.1`. The shared event file is a simple local control-plane bridge for this lab. It is not a network protocol and assumes the registry and Ryu controller run on the same Linux machine with access to the same file. The actual forwarding/blocking action is performed by OpenFlow in the switch.

When a service advertisement expires, the registry removes the instance. If no other active instance remains on that IP, it emits `BLOCK_HOST`. A new registration emits `UNBLOCK_HOST`. This makes application-level availability change the SDN data-plane behavior.

## 5. Requirements and environment

Recommended environment: **Ubuntu Linux VM** (for example Ubuntu 20.04/22.04) with sudo/root access. Mininet and Open vSwitch are Linux networking tools; Windows alone is not a suitable environment for this topology.

Install system packages (package names can vary slightly by Ubuntu release):

```bash
sudo apt update
sudo apt install -y mininet openvswitch-switch python3 python3-pip git
sudo pip3 install ryu
```

Check installation:

```bash
mn --version
ovs-vsctl --version
ryu-manager --version
python3 --version
```

If Ryu fails due to Python/package compatibility on a newer Ubuntu/Python version, use a supported Ubuntu VM or a Python virtual environment with compatible Ryu dependencies. Mininet and Open vSwitch still need to be installed at OS level.

No third-party Python package is needed for the UDP registry, service server, client, or protocol module; those use the Python standard library.

## 6. Run the project

Open **three terminal windows** in the project directory. The commands below assume the project folder is at `/path/to/udp-service-discovery`; replace that path with your actual path. Run the Ryu and Mininet terminals with the privileges required by your installation.

### Terminal 1 — start the SDN controller

Clear old events first so that events from a previous run are not replayed:

```bash
cd /path/to/udp-service-discovery
sudo ./scripts/reset_sdn_events.sh
sudo env SDN_EVENTS_FILE=/tmp/udp_sdn_events.jsonl ryu-manager --ofp-tcp-listen-port 6653 ryu_controller.py
```

Wait for Ryu to start. Keep this terminal open. You should see a switch connection when Mininet starts.

### Terminal 2 — start Mininet

```bash
cd /path/to/udp-service-discovery
sudo python3 topology.py
```

The Mininet CLI opens. The topology uses these fixed addresses:

| Node | IPv4 address | Purpose |
|---|---|---|
| `registry` | `10.0.0.1/24` | UDP registry, port 9999 |
| `server1` | `10.0.0.2/24` | Example service instance |
| `server2` | `10.0.0.3/24` | Second example service instance |
| `client1` | `10.0.0.4/24` | Test client |
| `client2` | `10.0.0.5/24` | Second test client |
| `s1` | — | OpenFlow 1.3 switch |

### Terminal 3 — start the registry and services through Mininet CLI

At the `mininet>` prompt, start the registry in the background (so the CLI remains available):

```text
mininet> registry python3 /path/to/udp-service-discovery/registry.py > /tmp/registry.log 2>&1 &
```

Start two service instances (use separate Mininet CLI commands; `&` backgrounds the processes):

```text
mininet> server1 python3 /path/to/udp-service-discovery/service_server.py --name weather --registry-ip 10.0.0.1 --port 10000 > /tmp/server1.log 2>&1 &
mininet> server2 python3 /path/to/udp-service-discovery/service_server.py --name maps --registry-ip 10.0.0.1 --port 10000 > /tmp/server2.log 2>&1 &
```

Check logs from the Mininet CLI:

```text
mininet> registry cat /tmp/registry.log
mininet> server1 cat /tmp/server1.log
```

Wait a few seconds for the first advertisements.

### Discover services

List all services:

```text
mininet> client1 python3 /path/to/udp-service-discovery/client.py --registry-ip 10.0.0.1
```

Find `weather` and send an example request to the first discovered instance:

```text
mininet> client1 python3 /path/to/udp-service-discovery/client.py --registry-ip 10.0.0.1 --service weather --invoke --payload "hello from Mininet"
```

Find the other service:

```text
mininet> client2 python3 /path/to/udp-service-discovery/client.py --registry-ip 10.0.0.1 --service maps --invoke
```

### Inspect the SDN flow table

From another host terminal (outside the Mininet CLI):

```bash
sudo ovs-ofctl -O OpenFlow13 dump-flows s1
```

Depending on how Mininet names the switch in your environment, this command should show the table-miss/learned forwarding flows. After a host is blocked, look for a priority-100 IPv4 destination rule matching that host's address.

### Stop the system

Stop individual services with `Ctrl-C` in their foreground process, or terminate their process from the Mininet host. A normal service shutdown sends `UNREGISTER`; a forced kill (`kill -9`) simulates a crash and lets TTL expiry detect the failure. Type `exit` at `mininet>` to stop the topology, then stop Ryu with `Ctrl-C`.

## 7. Test plan and expected results

Run these tests in order and capture terminal output/screenshots for your report/demo.

1. **Basic registration and discovery:** start registry and `weather`; discover `weather`. Expected: one endpoint `10.0.0.2:10000`.
2. **Multiple services:** start `maps` on server2; query all services. Expected: both service names appear.
3. **Invocation:** use `--invoke`. Expected: a `RESPONSE` with a matching request ID and a result string.
4. **Unknown service:** query `--service nonexistent`. Expected: empty list and `No matching active services found.`
5. **Graceful service exit:** stop one service normally. Expected: registry receives `UNREGISTER`, and Ryu removes any drop rule for that host only when a service registers again; the registry emits `BLOCK_HOST` if that host has no other live service.
6. **Crash / timeout:** forcibly terminate a service without `UNREGISTER`. Wait for the TTL (default 6 seconds) plus a small margin. Expected: registry logs `EXPIRED`; Ryu logs `SDN BLOCK`; the switch receives a priority-100 drop rule for the failed host IP.
7. **Recovery:** restart the same service. Expected: its next advertisement emits `UNBLOCK_HOST`; Ryu deletes the drop rule and the service becomes discoverable again.
8. **Multiple clients:** query from both `client1` and `client2`. Expected: both can discover and invoke services.
9. **Registry unavailable:** stop the registry and run a client. Expected: client exits after its configured timeout with a discovery failure rather than hanging forever.
10. **Protocol unit tests:** run the command below. Expected: all tests pass.

Unit tests (run outside Mininet):

```bash
cd /path/to/udp-service-discovery
python3 -m unittest discover -s tests -v
```

Repeatable discovery latency/success-rate benchmark (run inside Mininet while the registry is running):

```text
mininet> client1 python3 /path/to/udp-service-discovery/benchmark.py --registry-ip 10.0.0.1 --service weather --count 100
```

The benchmark prints actual average/minimum/maximum response latency and success rate for your run. Save its output for the performance section of your report.

Basic connectivity test inside Mininet:

```text
mininet> pingall
```

Note: if the SDN controller intentionally blocks a failed host, `pingall` can show expected loss to that host until it advertises again. Use the service-discovery tests and flow table as the main proof of dynamic behavior.

## 8. Performance evaluation for the rubric

The PDF asks for measured metrics, multiple conditions, and comparison against a suitable baseline/static approach. For your report, collect at least:

- **Discovery latency:** client request start to receipt of `DISCOVERY_RESULT` (milliseconds).
- **Discovery success rate:** successful responses divided by total attempts.
- **Failure detection time:** time between killing a service and the registry's `EXPIRED` event / Ryu's `SDN BLOCK` log.
- **Recovery time:** time between restarting a service and successful discovery / removal of the block rule.
- **Control-plane behavior:** count of `BLOCK_HOST` and `UNBLOCK_HOST` events and corresponding OpenFlow rules.

Suggested experiment table:

| Experiment | Setup | Measure |
|---|---|---|
| Baseline | Controller learning switch, no service crash | Average discovery latency and success rate |
| Multiple services | Two service providers and two clients | Discovery latency and correct endpoint count |
| Failure | Kill one server abruptly | Failure detection time and blocked flow appearance |
| Recovery | Restart the failed server | Recovery time and successful invocation |
| Repeated queries | Run 50–100 discovery commands | Average/min/max latency and success rate |

For a fair static-vs-dynamic comparison, repeat the same test with the dynamic block logic disabled (or without processing registry events) and compare what happens after a server failure. Record actual measurements from your VM; do **not** invent numbers. The dynamic design's primary intended benefit is to make the switch's forwarding policy reflect service availability, not necessarily to reduce normal discovery latency.

## 9. How the code works, step by step

1. `service_server.py` chooses the source IP it uses to reach the registry, binds its UDP service port, and sends a `REGISTER` datagram.
2. `registry.py` stores the service endpoint and an expiry timestamp (`now + TTL`). It replies `REGISTERED`.
3. The service server refreshes the advertisement roughly every one-third of its TTL.
4. A client sends `DISCOVER` to UDP port 9999. The registry returns only records whose expiry timestamp is still in the future.
5. If `--invoke` is supplied, the client sends a `REQUEST` datagram to the discovered service endpoint and prints its response.
6. If advertisements stop, the registry expires the record and appends `BLOCK_HOST` when that IP has no other live registered service.
7. Ryu reads the event and adds an OpenFlow priority-100 drop rule for packets destined to that IPv4 address.
8. A new registration emits `UNBLOCK_HOST`, and Ryu deletes the matching drop rule.

## 10. Limitations and improvements

- The registry is in-memory: restarting it clears registrations; services will re-register on their next heartbeat.
- UDP is unreliable. A dropped advertisement can temporarily make a service appear unavailable; periodic refresh mitigates this.
- The shared event file is intended for a single-machine lab. A distributed deployment should replace it with an authenticated controller API or message channel.
- A host-level drop rule blocks all IPv4 traffic to that host, not just one service port. This makes the SDN effect visible and simple for the assignment, but a production design should use narrower matches and authenticated policy.
- This is a basic learning-switch implementation, not a hardened controller. There is no authentication, encryption, replicated registry, or sophisticated load balancing.
- Service selection currently uses the first matching endpoint; clients do not yet perform health scoring or round-robin selection.
- The `UNREGISTER` / expiry policy blocks a host only when the registry has no other active service registered on that IP.

## 11. Mapping to the assignment rubric

| Assignment criterion | Project evidence |
|---|---|
| Problem understanding & architecture | This README, message table, architecture diagram, and component descriptions. |
| UDP socket implementation | `registry.py`, `service_server.py`, `client.py`, `protocol.py`. |
| Mininet + SDN | `topology.py`, Ryu OpenFlow 1.3 controller in `ryu_controller.py`. |
| Socket–SDN integration | Registry events lead to dynamic OpenFlow block/unblock rules. |
| Initial testing & demo | Test plan in Section 7 and protocol unit tests. |
| Complete functionality | Multiple service instances, discovery, request/response, timeout and unregister handling. |
| Dynamic SDN functionality | `BLOCK_HOST` / `UNBLOCK_HOST` OpenFlow rule changes. |
| Challenging scenario / robustness | Abrupt server crash, TTL expiry, recovery, client timeout tests. |
| Performance evaluation | Metrics and experiment plan in Section 8; record results from actual runs. |
| Documentation / viva | This README includes setup, protocol, flow, tests, limitations, and rubric mapping. |

## 12. Viva questions to prepare

- **Why UDP?** It is connectionless and lightweight, suitable for periodic announcements and short discovery messages. It has no built-in delivery guarantee, so TTL refresh and timeouts are needed.
- **What is a TTL?** The time a registration remains valid without a refresh. It prevents stale entries after a crash.
- **What is service discovery?** Finding an available service endpoint by querying a registry instead of hard-coding every server address.
- **What does SDN add?** The controller can change switch flow rules in response to service availability, rather than leaving forwarding policy static.
- **What is OpenFlow?** The protocol used by the controller to install and remove forwarding rules in the switch.
- **Why is the controller connection TCP if the app is UDP?** OpenFlow's control channel is separate from the project's application protocol. All service registration, discovery, and invocation messages use UDP.
- **What happens if a server crashes?** Its advertisements stop; the registry expires the registration; Ryu installs a drop rule; a later registration removes the rule.
- **What are the limitations?** UDP loss, in-memory registry, single controller/event file, no authentication, and host-level rather than port-level blocking.
