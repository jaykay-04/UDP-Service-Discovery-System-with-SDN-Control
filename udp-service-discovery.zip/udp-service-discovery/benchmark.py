#!/usr/bin/env python3
"""Measure UDP service-discovery request latency and success rate."""
import argparse
import statistics
import time

from protocol import DEFAULT_REGISTRY_PORT, decode, encode
import socket


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry-ip", required=True)
    parser.add_argument("--registry-port", type=int, default=DEFAULT_REGISTRY_PORT)
    parser.add_argument("--service", default="", help="service name or empty for all services")
    parser.add_argument("--count", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=1.0)
    args = parser.parse_args()
    if args.count < 1:
        parser.error("--count must be at least 1")

    samples_ms = []
    failures = 0
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(args.timeout)
        target = (args.registry_ip, args.registry_port)
        for _ in range(args.count):
            start = time.perf_counter()
            try:
                sock.sendto(encode({"type": "DISCOVER", "service": args.service}), target)
                payload, _ = sock.recvfrom(65507)
                result = decode(payload)
                elapsed = (time.perf_counter() - start) * 1000
                if result.get("type") != "DISCOVERY_RESULT":
                    failures += 1
                else:
                    samples_ms.append(elapsed)
            except (socket.timeout, OSError, ValueError):
                failures += 1
    success = len(samples_ms)
    print(f"attempts: {args.count}")
    print(f"successful discovery responses: {success}")
    print(f"failures: {failures}")
    print(f"success rate: {success / args.count * 100:.2f}%")
    if samples_ms:
        print(f"latency average: {statistics.mean(samples_ms):.3f} ms")
        print(f"latency min: {min(samples_ms):.3f} ms")
        print(f"latency max: {max(samples_ms):.3f} ms")
        if len(samples_ms) > 1:
            print(f"latency stdev: {statistics.stdev(samples_ms):.3f} ms")


if __name__ == "__main__":
    main()
