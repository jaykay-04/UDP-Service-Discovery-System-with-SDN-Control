import unittest
from protocol import decode, encode


class ProtocolTests(unittest.TestCase):
    def test_round_trip(self):
        original = {"type": "DISCOVER", "service": "weather"}
        self.assertEqual(decode(encode(original)), {"version": 1, **original})

    def test_rejects_wrong_version(self):
        with self.assertRaises(ValueError):
            decode(b'{"version":99,"type":"PING"}')

    def test_rejects_non_object(self):
        with self.assertRaises(ValueError):
            decode(b'[]')


if __name__ == "__main__":
    unittest.main()
