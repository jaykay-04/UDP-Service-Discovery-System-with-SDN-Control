#!/usr/bin/env python3
"""Ryu OpenFlow 1.3 learning switch with registry-driven dynamic host blocking.

The registry and Ryu process share SDN_EVENTS_FILE on the same machine. The
registry appends JSON events; this controller translates BLOCK_HOST and
UNBLOCK_HOST events into OpenFlow rules. This avoids requiring Mininet hosts to
reach the controller process's localhost interface.
"""
import json
import os
import time

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ether_types


class ServiceDiscoverySDN(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(ServiceDiscoverySDN, self).__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.datapaths = {}
        self.event_file = os.environ.get("SDN_EVENTS_FILE", "/tmp/udp_sdn_events.jsonl")
        self.event_offset = 0
        self.blocked_hosts = set()
        self.monitor_thread = hub.spawn(self._poll_event_file)
        self.logger.info("ServiceDiscoverySDN started; watching %s", self.event_file)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        self.datapaths[datapath.id] = datapath
        parser, ofproto = datapath.ofproto_parser, datapath.ofproto
        # Send unknown packets to controller for MAC learning.
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self._add_flow(datapath, 0, match, actions)
        self.logger.info("Switch connected: dpid=%s (OpenFlow 1.3)", datapath.id)
        for ip in list(self.blocked_hosts):
            self._block_ip(datapath, ip)

    def _add_flow(self, datapath, priority, match, actions=None, buffer_id=None):
        parser, ofproto = datapath.ofproto_parser, datapath.ofproto
        instructions = []
        if actions is not None:
            instructions = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        kwargs = {"datapath": datapath, "priority": priority, "match": match,
                  "instructions": instructions}
        if buffer_id is not None:
            kwargs["buffer_id"] = buffer_id
        datapath.send_msg(parser.OFPFlowMod(**kwargs))

    def _block_ip(self, datapath, ip):
        parser = datapath.ofproto_parser
        match = parser.OFPMatch(eth_type=ether_types.ETH_TYPE_IP, ipv4_dst=ip)
        self._add_flow(datapath, 100, match, actions=None)
        self.logger.warning("SDN BLOCK: installed drop rule for IPv4 destination %s on dpid=%s", ip, datapath.id)

    def _unblock_ip(self, datapath, ip):
        parser, ofproto = datapath.ofproto_parser, datapath.ofproto
        match = parser.OFPMatch(eth_type=ether_types.ETH_TYPE_IP, ipv4_dst=ip)
        datapath.send_msg(parser.OFPFlowMod(
            datapath=datapath, command=ofproto.OFPFC_DELETE,
            out_port=ofproto.OFPP_ANY, out_group=ofproto.OFPG_ANY,
            priority=100, match=match))
        self.logger.info("SDN UNBLOCK: removed drop rule for IPv4 destination %s on dpid=%s", ip, datapath.id)

    def _apply_event(self, event):
        action, ip = event.get("action"), event.get("ip")
        if not ip or action not in ("BLOCK_HOST", "UNBLOCK_HOST"):
            self.logger.warning("Ignoring malformed SDN event: %s", event)
            return
        if action == "BLOCK_HOST":
            self.blocked_hosts.add(ip)
            for datapath in list(self.datapaths.values()):
                self._block_ip(datapath, ip)
        else:
            self.blocked_hosts.discard(ip)
            for datapath in list(self.datapaths.values()):
                self._unblock_ip(datapath, ip)

    def _poll_event_file(self):
        while True:
            try:
                if not os.path.exists(self.event_file):
                    hub.sleep(0.5)
                    continue
                size = os.path.getsize(self.event_file)
                if size < self.event_offset:  # file was truncated/recreated
                    self.event_offset = 0
                with open(self.event_file, "r", encoding="utf-8") as f:
                    f.seek(self.event_offset)
                    new_content = f.read()
                    self.event_offset = f.tell()
                for line in new_content.splitlines():
                    try:
                        self._apply_event(json.loads(line))
                    except (json.JSONDecodeError, TypeError) as exc:
                        self.logger.warning("Bad event line ignored (%s): %r", exc, line)
            except OSError as exc:
                self.logger.warning("Could not read SDN event file: %s", exc)
            hub.sleep(0.5)

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER])
    def state_change_handler(self, ev):
        datapath = ev.datapath
        self.datapaths[datapath.id] = datapath

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg, datapath = ev.msg, ev.msg.datapath
        parser, ofproto = datapath.ofproto_parser, datapath.ofproto
        in_port = msg.match["in_port"]
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if eth is None or eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return
        dst, src = eth.dst, eth.src
        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][src] = in_port
        out_port = self.mac_to_port[dpid].get(dst, ofproto.OFPP_FLOOD)
        actions = [parser.OFPActionOutput(out_port)]
        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(in_port=in_port, eth_dst=dst, eth_src=src)
            self._add_flow(datapath, 1, match, actions, msg.buffer_id if msg.buffer_id != ofproto.OFP_NO_BUFFER else None)
        data = None if msg.buffer_id != ofproto.OFP_NO_BUFFER else msg.data
        datapath.send_msg(parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                             in_port=in_port, actions=actions, data=data))

