#!/usr/bin/env bash
set -euo pipefail
EVENT_FILE="${SDN_EVENTS_FILE:-/tmp/udp_sdn_events.jsonl}"
: > "$EVENT_FILE"
echo "Cleared SDN event log: $EVENT_FILE"
